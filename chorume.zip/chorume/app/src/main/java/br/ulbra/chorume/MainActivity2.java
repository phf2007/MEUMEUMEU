package br.ulbra.chorume;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {
    EditText edt1;
    RadioButton rb1;
    RadioButton rb2;
    RadioButton rb3;
    CheckBox cb1;
    Button btn1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edt1 = findViewById((R.id.edt1));
        rb1 = findViewById((R.id.rb1));
        rb2 = findViewById((R.id.rb2));
        rb3 = findViewById((R.id.rb3));
        cb1 = findViewById((R.id.cb1));
        btn1 = findViewById((R.id.btn1));
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1,resultado,res2,res3;
                v1=Double.parseDouble(edt1.getText().toString());
                if (rb1.isChecked()){
                    resultado=v1*0.5;
                    edt1.setText("Resultado: "+resultado+" passos por metros.");
                    if (cb1.isChecked()){
                        res2=(resultado*10)/100;
                        res3=resultado+res2;
                        edt1.setText("Resultado: "+res3+" passos por metros.");
                    }
                    edt1.setText("Resultado: "+resultado+" passos por metros.");
                }
                if (rb2.isChecked()){
                    resultado=v1*0.7;
                    edt1.setText("Resultado: "+resultado+" passos por metros.");
                    if (cb1.isChecked()){
                        res2=(resultado*10)/100;
                        res3=resultado+res2;
                        edt1.setText("Resultado: "+res3+" passos por metros.");
                    }
                }
                if (rb3.isChecked()){
                    resultado=v1*1.0;
                    edt1.setText("Resultado: "+resultado+" passos por metros.");
                    if (cb1.isChecked()){
                        res2=(resultado*10)/100;
                        res3=resultado+res2;
                        edt1.setText("Resultado: "+res3+" passos por metros.");
                    }
                } //caralho
            }
        });

    }
}